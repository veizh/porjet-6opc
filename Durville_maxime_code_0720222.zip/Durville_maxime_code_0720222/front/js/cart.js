function afficherPanier() {
  let products = localStorage.getItem("products");
  const cart__items = document.getElementById("cart__items");

  if (products == null) {
    [];
  } else {
    products = JSON.parse(products);
    var totalQuantity = 0;
    var totalPrice = 0;

    products.forEach((element, index) => {
      fetch("http://localhost:3000/api/Products/" + element.id)
        .then((res) => res.json())
        .then((items) => {
          /**************** start style ****************************/

          /* article */

          let article = document.createElement("article");
          article.setAttribute("class", "cart__item article");
          cart__items.appendChild(article);

          /* image + parent image */

          let cart__item__img = document.createElement("div");
          cart__item__img.setAttribute("class", "cart__item__img");
          let img = document.createElement("img");
          img.setAttribute("src", items.imageUrl);
          cart__item__img.appendChild(img);
          article.appendChild(cart__item__img);

          /* parent description */

          let cart__item__content = document.createElement("div");
          cart__item__content.setAttribute("class", "cart__item__content");
          article.appendChild(cart__item__content);
          let cart__item__content__description = document.createElement("div");
          cart__item__content__description.setAttribute(
            "class",
            "cart__item__content__description"
          );
          cart__item__content.appendChild(cart__item__content__description);

          /* name product */

          let name = document.createElement("h2");
          name.innerHTML = items.name;
          cart__item__content__description.appendChild(name);

          /* couleur */

          let colori = document.createElement("p");
          colori.innerHTML = element.color;
          cart__item__content__description.appendChild(colori);

          /* price element * quantity */

          let prix = document.createElement("p");
          prix.innerHTML = items.price * element.quantity + "€";
          cart__item__content__description.appendChild(prix);

          /* parent setting */

          let cart__item__content__settings = document.createElement("div");
          cart__item__content__settings.setAttribute(
            "class",
            "cart__item__content__settings"
          );
          cart__item__content.appendChild(cart__item__content__settings);

          /* boutton supprimer */

          let cart__item__content__settings__quantity =
            document.createElement("div");
          cart__item__content__settings__quantity.setAttribute(
            "class",
            "cart__item__content__settings__quantity"
          );
          cart__item__content__settings.appendChild(
            cart__item__content__settings__quantity
          );

          /* txt quantity */

          let qte = document.createElement("p");
          qte.innerHTML = "Qté :";
          cart__item__content__settings__quantity.appendChild(qte);

          /* input quantity*/

          let nbquantity = document.createElement("input");
          nbquantity.setAttribute("type", "number");
          nbquantity.setAttribute("min", "1");
          nbquantity.setAttribute("max", "100");
          nbquantity.setAttribute("value", element.quantity);
          nbquantity.setAttribute("class", "itemQuantity");
          nbquantity.setAttribute("name", "itemQuantity");
          cart__item__content__settings__quantity.appendChild(nbquantity);

          let itemQuantity = element.quantity;

          nbquantity.addEventListener("change", (e) => {
            let products = localStorage.getItem("products");
            products = JSON.parse(products);

            let newPrice = e.target.value * items.price;

            prix.textContent = newPrice + "€";
            totalPrice =
              totalPrice -
              (itemQuantity * items.price - e.target.value * items.price);
            document.getElementById("totalPrice").textContent = totalPrice;

            totalQuantity = totalQuantity - (itemQuantity - e.target.value);
            document.getElementById("totalQuantity").textContent =
              totalQuantity;
            itemQuantity = e.target.value;
            products[index].quantity = itemQuantity;
            products = localStorage.setItem(
              "products",
              JSON.stringify(products)
            );

            console.log(
              "je m'ecrase dans le localstorage en mettant a jour la quantite du produit en question"
            );
          });

          /* Parent boutton supprimer */

          let cart__item__content__settings__delete =
            document.createElement("div");
          cart__item__content__settings__delete.setAttribute(
            "class",
            "cart__item__content__settings__delete"
          );
          cart__item__content__settings__quantity.appendChild(
            cart__item__content__settings__delete
          );

          /* boutton supprimer */

          let supp = document.createElement("p");
          supp.setAttribute("class", "deleteItem");
          supp.innerHTML = "Supprimer";
          cart__item__content__settings__delete.appendChild(supp);
          supp.setAttribute("value", element.checkDoublon);

          supp.addEventListener("click", (e) => {
            let products = localStorage.getItem("products");
            products = JSON.parse(products);
            e.target.closest(".article").remove();
            console.log("remove article front");

            /* modifier sur le local sotrage */
            totalQuantity -= element.quantity;
            totalPrice -= items.price * element.quantity;
            products.splice(index, 1);
            console.log(totalQuantity);
            console.log(totalPrice);

            document.getElementById("totalPrice").textContent = totalPrice;
            document.getElementById("totalQuantity").textContent =
              totalQuantity;

            products = localStorage.setItem(
              "products",
              JSON.stringify(products)
            );
            console.log("remove article from localStorage");
          });

          /**************** end style ****************************/

          totalPrice = element.quantity * items.price + totalPrice;
          totalQuantity = totalQuantity + element.quantity;

          document.getElementById("totalPrice").innerHTML = totalPrice;

          document.getElementById("totalQuantity").innerHTML = totalQuantity;

          if (index == products.length - 1) {
            console.log("j'ai fini le fetch de mon api");
            console.log(products)
          }
        });
    });
  }
}

afficherPanier();



/* traiter le formulaire */

let form = document.querySelector(".cart__order__form");
form.addEventListener('submit', (e) => {

  e.preventDefault()

  /*verification du prenom :lettre seulement et espace */
  let firstName = document.getElementById('firstName')
  let firstNameErrorMsg = document.getElementById('firstNameErrorMsg')
  let errorForm = 0

  firstNameErrorMsg.innerHTML=""
  if(myRegexNames.test(firstName.value) == false ){
   firstNameErrorMsg.innerHTML ="Le prénom doit uniquements contenir des lettres et des tirets !"
   errorForm ++

  }

  /*verification du nom: lettre seulement et espace */
  let lastName = document.getElementById('lastName')
  let lastNameErrorMsg = document.getElementById('lastNameErrorMsg')
  lastNameErrorMsg.innerHTML=""
  if(myRegexNames.test(lastName.value) == false ){
    lastNameErrorMsg.innerHTML ="Le nom doit uniquements contenir des lettres et des tirets !"
    errorForm ++
  }

   /*verification de l'adresse: lettre, chiffre et  espaces seuelements */
   let address = document.getElementById('address')
   let addressErrorMsg = document.getElementById('addressErrorMsg')
   addressErrorMsg.innerHTML=""
   if(myRegexAdress.test(address.value) == false ){
    addressErrorMsg.innerHTML ="L'addresse doit contenir au minimum deux caractères et 1 chiffre"
    errorForm ++
   }

   /*verification de la ville : lettre, chiffre et  espaces seuelements */
   let city = document.getElementById('city')
   let cityErrorMsg = document.getElementById('cityErrorMsg')
   cityErrorMsg.innerHTML=""
   if(myRegexCity.test(city.value) == false ){
    cityErrorMsg.innerHTML ="Le format de la ville peut contenir uniquement des lettres, des tirets et des espaces !"
    errorForm ++
   }

    /*verification de l'adresse mail : lettre, chiffre et  espaces seuelements */
    let email = document.getElementById('email')
    let emailErrorMsg = document.getElementById('emailErrorMsg')
    emailErrorMsg.innerHTML=""

    if(myRegexMail.test(email.value) == false ){
      emailErrorMsg.innerHTML ="Le format de l'adresse email n'est pas valide !"
      errorForm ++
    }
  
    if(errorForm == 0){
      let products = localStorage.getItem("products");
      products = JSON.parse(products)
      let  contact = {
          "firstName":firstName.value,
          "lastName":lastName.value,
          "address":address.value,
          "city":city.value,
          "email":email.value
        }


      let idProducts =[];
      
        products.forEach(element => {
          idProducts.push(element.id)
          console.log(idProducts)
      });
      

      let data = {
        "contact":contact,
        "products":idProducts
      }
      console.log(data)
      fetch('http://localhost:3000/api/products/order',{
        method:"POST",
        headers:{
          "content-type":"application/json"
        },
        body: JSON.stringify(data)
        })
        .then(res => res.json())
        .then(res => {
          console.log(res.orderId)
          localStorage.clear()
          window.location='http://127.0.0.1:5500/front/html/confirmation.html?orderId='+res.orderId

        })
    }
})
/**
 *
 * Expects request to contain:
 * contact: {
 *   firstName: string,
 *   lastName: string,
 *   address: string,
 *   city: string,
 *   email: string
 * }
 * products: [string] <-- array of product _id
 *
 */

let myRegexNames = /^[a-zA-Z-\s]+$/
let myRegexAdress = /[\w,.]{2,50}/
let myRegexCity = /[\w,.]{2,50}/
var myRegexMail = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/