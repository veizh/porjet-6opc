
const params = new URLSearchParams(window.location.search)
const paramsId = params.get("id")

var prix = document.querySelector('#price')
var imgLocation= document.querySelector('.item__img')
var title = document.querySelector('#title')
var desc = document.querySelector('#description')
var colors = document.querySelector('#colors')
var boutton = document.querySelector('#addToCart')
var quantite = document.getElementById('quantity')


fetch("http://localhost:3000/api/Products/"+paramsId)
    .then(res => res.json())
    .then(item => {
        console.log(item.price)
        /*Image*/
        var img = document.createElement('img')
        img.setAttribute('src',item.imageUrl)
        imgLocation.appendChild(img)

        /*prix*/
        prix.innerHTML=item.price
        /*title*/
        title.innerHTML=item.name
        /*description*/
        desc.innerHTML=item.description
        /*colors*/
        item.colors.forEach(element => {
            var option = document.createElement('option')
            option.setAttribute('value',element)
            option.innerHTML=element
            colors.appendChild(option)

        
        });
    })
 
    boutton.onclick = ()=>{
        let product = {
            id:paramsId,
            color:colors.value,
            quantity:parseInt(quantite.value),
            checkDoublon:paramsId+colors.value
        }
        /********************************  CHECK SI L UTILISATEUR A BIEN CHOISIS UNE COULEUR ET UN NOMBRE DE PRODUITS************************************************* */
        if(!colors.value){
            return alert(" Veuillez choisir une couleur !")
        }
        if(quantite.value<1){
            return alert(" Veuillez selectionner le nombre de produits souhaités !")
        }
       pushProduct(product)}


/***    On veut créer plusieurs fonctions une premiere qui permet de push l'article dans le local storage 
        Une autre qui permet de le mettre a jour 
        Une qui permet d'additionner la quantité de produit avec la meme id et la meme  couleur   **/
        
function pushProduct(product){
    let products = getProduct()
     let foundProductDoublon = products.find(e => e.checkDoublon == product.checkDoublon)
    if(foundProductDoublon != null){
        foundProductDoublon.quantity += product.quantity
        console.log("j'existe deja => je m'ecrase et j'additione la quantité des produits simillaires") 
    }
    else{
        console.log("je suis nouveau") 
        products.push(product)
    }
    localStorage.setItem("products",JSON.stringify(products))
}
function getProduct(){
   let  products =localStorage.getItem('products')
   if( products == null){
    return []
   }
   else{
    return JSON.parse(products)
   }
}
