
var parent =document.getElementById('items')

fetch('http://localhost:3000/api/products')
    .then(res => res.json())
    .then(items => {
        items.forEach(item => {
            console.log(item)
            /* card + url pour la page product*/
            var card = document.createElement("a")
            card.setAttribute('href',"./product.html?id="+item._id)
             /* article */
            var article = document.createElement("article")
            card.appendChild(article)
            /* img */
            var img = document.createElement("img")
            img.setAttribute("src",item.imageUrl)
            article.appendChild(img)
            /* Name */
            var productName = document.createElement("h3")
            productName.setAttribute('class','productName')
            productName.innerHTML = item.name
            article.appendChild(productName)
            /* Description */
            var productDesc = document.createElement("p")
            productDesc.setAttribute('class',"productDescription")
            productDesc.innerHTML = item.description
            article.appendChild(productDesc)
            /*push card */
            parent.appendChild(card)
        });
    })
