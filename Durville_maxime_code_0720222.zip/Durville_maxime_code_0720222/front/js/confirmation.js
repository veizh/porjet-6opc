let params = new URLSearchParams(window.location.search)
/* on recupere le parametre passer dans l'url : console.log(params.get('orderId')) */
let orderId = document.getElementById('orderId')
orderId.innerHTML =params.get('orderId')